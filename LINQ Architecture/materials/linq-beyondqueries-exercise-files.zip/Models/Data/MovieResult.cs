namespace BeyondQueries.Models.Data
{
    public enum MovieResult
    {
        NotEnoughInformation, 
        GoodMovie,
        BadMovie
    } 
}