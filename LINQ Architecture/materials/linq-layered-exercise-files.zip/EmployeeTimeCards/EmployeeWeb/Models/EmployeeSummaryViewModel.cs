namespace EmployeeWeb.Models
{
    public class EmployeeSummaryViewModel
    {
        public string Name { get; set; }
        public int TotalTimeCards { get; set; }
    }
}