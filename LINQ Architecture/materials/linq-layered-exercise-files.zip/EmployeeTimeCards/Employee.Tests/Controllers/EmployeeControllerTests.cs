using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Employee.Tests.Controllers
{
    [TestClass]
    public class EmployeeControllerTests
    {
        [TestMethod]
        public void Index_action_model_contains_all_employees()
        {
            
        }



    }
}